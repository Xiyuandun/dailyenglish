// DailyEnglish - 语音工具（云端 TTS + Web Speech API fallback）
// 优先使用云端 TTS（edge-tts Jenny 声音，自然亲切，类似豆包）
// 云端不可用时自动回退到浏览器内置语音合成
const Speech = {
  audio: null,          // Audio 对象用于播放云端 TTS 音频
  synth: window.speechSynthesis || null,
  rec: null,
  voices: [],
  queuedTimers: [],     // 排队朗读的定时器（便于一键停止）

  // 云端 TTS 配置
  ttsBase: '/tts',      // TTS API 端点
  voice: 'jenny',       // 默认语音（Jenny 女声，类似豆包）
  useCloudTTS: true,    // 是否使用云端 TTS
  _lastText: '',        // 记录上次朗读文本（用于 fallback）
  _lastRate: 1,         // 记录上次速率
  _cloudFailedCount: 0, // 云端失败计数（连续失败则禁用）

  // 可选语音列表
  voiceOptions: {
    jenny:  { id: 'jenny',  label: 'Jenny（女声·自然）',  edge: 'en-US-JennyNeural' },
    aria:   { id: 'aria',   label: 'Aria（女声·温暖）',   edge: 'en-US-AriaNeural' },
    guy:    { id: 'guy',    label: 'Guy（男声·自然）',    edge: 'en-US-GuyNeural' },
    davis:  { id: 'davis',  label: 'Davis（男声）',       edge: 'en-US-DavisNeural' },
    amber:  { id: 'amber',  label: 'Amber（女声）',       edge: 'en-US-AmberNeural' },
    emma:   { id: 'emma',   label: 'Emma（英式女声）',    edge: 'en-GB-EmmaNeural' },
    brian:  { id: 'brian',  label: 'Brian（英式男声）',   edge: 'en-GB-BrianNeural' },
  },

  init() {
    // 初始化 Audio 对象
    this.audio = new Audio();
    this.audio.preload = 'auto';

    // Audio 播放失败 → 回退到 Web Speech
    this.audio.addEventListener('error', () => {
      this._cloudFailedCount++;
      console.warn(`云端 TTS 失败 (${this._cloudFailedCount}次)，回退到浏览器语音`);
      if (this._cloudFailedCount >= 3) {
        this.useCloudTTS = false;
        console.warn('云端 TTS 连续失败 3 次，已切换到浏览器内置语音');
      }
      if (this._lastText) {
        this._speakFallback(this._lastText, this._lastRate);
      }
    });

    // 播放成功时重置失败计数
    this.audio.addEventListener('playing', () => {
      this._cloudFailedCount = 0;
    });

    // 初始化 Web Speech API（作为 fallback）
    if (this.synth) {
      const load = () => { this.voices = this.synth.getVoices(); };
      load();
      this.synth.onvoiceschanged = load;
    }
  },

  // 朗读英文（主入口）
  speak(text, rate = 1) {
    this.stop();
    this._lastText = text;
    this._lastRate = rate;

    if (this.useCloudTTS) {
      this._speakCloud(text, rate);
    } else {
      this._speakFallback(text, rate);
    }
  },

  // 云端 TTS 朗读
  _speakCloud(text, rate) {
    const url = `${this.ttsBase}?text=${encodeURIComponent(text)}&voice=${this.voice}&rate=${rate}`;
    this.audio.src = url;
    this.audio.playbackRate = 1;
    this.audio.play().catch(err => {
      console.warn('云端 TTS 播放失败:', err);
      this._speakFallback(text, rate);
    });
  },

  // Web Speech API fallback（浏览器内置语音）
  _speakFallback(text, rate) {
    if (!this.synth) { Toast.show('语音合成不可用，请使用 Chrome 浏览器'); return; }
    this.synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-US';
    u.rate = rate;
    // 优先选择 Google 语音（较自然）
    let v = this.voices.find(v => v.name.includes('Google') && v.lang.startsWith('en'));
    if (!v) v = this.voices.find(v => v.lang.startsWith('en-US'));
    if (!v) v = this.voices.find(v => v.lang.startsWith('en'));
    if (v) u.voice = v;
    this.synth.speak(u);
  },

  // 停止所有朗读（取消当前 + 清空排队定时器）
  stop() {
    if (this.queuedTimers && this.queuedTimers.length) {
      this.queuedTimers.forEach(t => clearTimeout(t));
      this.queuedTimers = [];
    }
    // 停止云端 TTS 音频
    if (this.audio) {
      this.audio.pause();
      this.audio.currentTime = 0;
    }
    // 停止 Web Speech
    if (this.synth) this.synth.cancel();
  },

  // 切换语音
  setVoice(voiceId) {
    if (this.voiceOptions[voiceId]) {
      this.voice = voiceId;
      // 切换后重新启用云端 TTS
      this.useCloudTTS = true;
      this._cloudFailedCount = 0;
    }
  },

  // 检查浏览器是否支持语音识别
  isSupported() {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  },

  // 识别用户发音（返回 Promise<{text, error}>）
  // continuous=true 支持多句连续识别；error 非空时表示识别出错
  recognize(lang = 'en-US', timeoutMs = 6000) {
    return new Promise((resolve) => {
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SR) { resolve({ text: '', error: 'unsupported' }); return; }
      const r = new SR();
      r.lang = lang;
      r.continuous = true;       // 连续模式：支持多句台词一口气说完
      r.interimResults = false;
      r.maxAlternatives = 1;
      let done = false;
      let chunks = [];

      const finish = (error = '') => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve({ text: chunks.join(' ').trim(), error });
      };

      const timer = setTimeout(() => {
        try { r.stop(); } catch {}
        finish('');
      }, timeoutMs);

      // continuous 模式下可能触发多次 result 事件，累加所有识别片段
      r.onresult = (e) => {
        for (let i = 0; i < e.results.length; i++) {
          if (e.results[i].isFinal) {
            chunks.push(e.results[i][0].transcript.trim());
          }
        }
      };
      r.onerror = (e) => {
        // 常见错误：not-allowed（无权限）、no-speech（没说话）、network
        const errType = e.error || 'unknown';
        if (errType === 'no-speech') {
          finish('');  // 没说话不算错误，返回空文本
        } else if (errType === 'not-allowed' || errType === 'service-not-allowed') {
          finish('no-permission');
        } else if (errType === 'network') {
          finish('network');
        } else {
          finish('');
        }
      };
      r.onend = () => finish('');
      try { r.start(); } catch (err) { finish('start-failed'); }
    });
  },

  // 简易发音评分：基于识别文本与目标词的相似度
  scorePron(recognized, target) {
    if (!recognized) return 0;
    const a = recognized.toLowerCase().replace(/[^a-z\s]/g, '');
    const b = target.toLowerCase().replace(/[^a-z\s]/g, '');
    if (!b) return 0;
    // 用 Levenshtein 距离
    const dist = this.levenshtein(a, b);
    const maxLen = Math.max(a.length, b.length);
    let score = Math.round((1 - dist / maxLen) * 100);
    if (score < 0) score = 0;
    if (score > 100) score = 100;
    return score;
  },

  levenshtein(a, b) {
    const m = a.length, n = b.length;
    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        dp[i][j] = a[i-1] === b[j-1]
          ? dp[i-1][j-1]
          : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]);
      }
    }
    return dp[m][n];
  }
};

// DailyEnglish - 主应用控制器
function switchTab(name) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
  const panel = document.getElementById('tab-' + name);
  if (panel) panel.classList.remove('hidden');
  document.querySelectorAll('.tab-btn').forEach(b => {
    const active = b.dataset.tab === name;
    b.className = `tab-btn px-4 py-2 rounded-lg whitespace-nowrap text-sm font-medium ${active ? 'bg-brand-600 text-white' : 'bg-slate-100 dark:bg-slate-700'}`;
  });
  // 模块初始化
  if (name === 'words') WordModule.init();
  if (name === 'dialogue') DialogueModule.init();
  if (name === 'reading') ReadingModule.init();
  if (name === 'report') ReportModule.init();
  if (name === 'home') Store.refreshBadges();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
window.switchTab = switchTab;

document.addEventListener('DOMContentLoaded', () => {
  Speech.init();
  // 日期显示
  document.getElementById('todayDate').textContent = new Date().toLocaleDateString('zh-CN', { year:'numeric', month:'long', day:'numeric', weekday:'long' });

  // 主题
  const applyTheme = (dark) => {
    document.documentElement.classList.toggle('dark', dark);
    document.getElementById('themeToggle').textContent = dark ? '☀️' : '🌙';
  };
  const s = Store.get();
  applyTheme(s.dark);
  document.getElementById('themeToggle').onclick = () => {
    const ns = Store.get();
    ns.dark = !ns.dark;
    Store.save(ns);
    applyTheme(ns.dark);
  };

  // 打卡按钮
  document.getElementById('checkinBtn').onclick = () => Store.checkin();

  // 周打卡点
  const dots = document.getElementById('weekDots');
  let dotsHtml = '';
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000);
    const ds = d.toDateString();
    const checked = s.lastCheckin === ds || (i === 0 && s.lastCheckin === ds);
    dotsHtml += `<div class="w-7 h-7 rounded-full flex items-center justify-center text-xs ${checked ? 'bg-emerald-500 text-white' : 'bg-slate-200 dark:bg-slate-600 text-slate-400'}">${d.getDate()}</div>`;
  }
  dots.innerHTML = dotsHtml;

  // 初始化徽章
  Store.refreshBadges();

  // Tab 切换
  document.querySelectorAll('.tab-btn').forEach(b => {
    b.onclick = () => switchTab(b.dataset.tab);
  });
});
